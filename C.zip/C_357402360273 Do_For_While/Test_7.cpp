#include <stdio.h>
#include <conio.h>
#define PI 3.14
main(){
       
       float R, H, sumR, V;
       //
       printf("Please input R : ");
       scanf("%f", &R);
       //
       printf("Please input H : ");
       scanf("%f", &H);
       //
       sumR = R * R;
       V = PI * sumR * H;
       
       printf("\nR x R is : %.2f\n", sumR);
       printf("V is : %.2f\n", V);
       //
       getch();
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       }
