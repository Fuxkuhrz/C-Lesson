#include <stdio.h>
#include <conio.h>

main(){
       
       int x, y, sum;
       x = 5;
       y = 1;
       sum = 0; 
       while(x<=50){
               
       printf("\nSum%d = %d + %d", y, sum, x);     
       sum = sum + x;
       printf(" = %d", sum);  
       x=x+5;
       y=y+1;        
               
       }
       
       
       
       getch();
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       }
