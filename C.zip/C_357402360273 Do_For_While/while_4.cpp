#include <stdio.h>
#include <conio.h>


main(){
       
       int n = 0, i = 1;
       
       printf("\n Even Number\t\t\t Odd Number");
       printf("\n =================================================\n");
       
       
       while(n<=21, i<=21){
       printf("\n\t%d \t\t", n);
       printf("\t\t%d\n", i);        
       n = n + 2;
       i = i + 2;        
       }
       
       printf("\n Press any key to continue.....\n");
       getch();
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       }
