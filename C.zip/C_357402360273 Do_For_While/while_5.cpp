#include <stdio.h>
#include <conio.h>


main(){
       
       int n = 1;
       int y, x;
       int max;
       
       
       printf("\n Input x : ");
       scanf("%d", &x);
       printf("\n Input MAX : ");
       scanf("%d", &max);
       
       do{
          y = x*n;
          printf("\n %d x %d = %3d\n",x , n, y);         
          n=n+1;         
          }while(n<=max);
          
          
          
          
       getch();
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       }
