#include <stdio.h>
#include <conio.h>

main(){
       
       int score;
       printf("Input your score : ");
       scanf("%d", &score);
       
       if(score > 70){
       printf("\nCongratulations.\n");
       printf("You are pass.\n");
       }
       else{
       printf("\nSorry, try again.\n");
       printf("Not pass.\n");
       }
       
       
       getch();
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       }
