#include <stdio.h>
#include <conio.h>

main()
{
       
       printf("Hello C++\t");
       printf("I'm Computer Science\t");
       printf("I Love Computer Programming");
       getch();
}
