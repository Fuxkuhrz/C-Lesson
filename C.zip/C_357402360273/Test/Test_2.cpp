#include <stdio.h>
#include <conio.h>

main()
{
      printf("\n\n\n\n\n");
      printf("\t\t\t==> ^^My Profile^^ <==\n\n\n");
      printf("\t\t\t==> Hello Everyone.\n");
      printf("\t\t\t==> My name is Anuwat Khongchuai.\n");
      printf("\t\t\t==> My nick name is Palm.\n");
      printf("\t\t\t==> My Group : IT411.\n");
      printf("\t\t\t==> My Department  : Information Technology.\n");
      printf("\t\t\t==> Age : 20 years old.\n");
      printf("\t\t\t==> Birthday : 4th December 1995.\n");
      printf("\t\t\t==> I Love Computer Programming.\n\n");
      
      printf("\t\t\t_____########*____\n");
      printf("\t\t\t__#############*__\n");
      printf("\t\t\t_################*_____________####____\n");
      printf("\t\t\t ###################*_______########____\n");
      printf("\t\t\t_####################**___###########_____\n");
      printf("\t\t\t __#################**___#############____\n");
      printf("\t\t\t  __################**_**############____\n");
      printf("\t\t\t   ___##############################____\n");
      printf("\t\t\t    ____###########################____\n");
      printf("\t\t\t     ______#######################____\n");
      printf("\t\t\t         ____####################____\n");
      printf("\t\t\t           _____################___\n");
      printf("\t\t\t              ____#############__\n");
      printf("\t\t\t                 ___##########__\n");
      printf("\t\t\t                 ____########__\n");
      printf("\t\t\t                   ___######__\n");
      printf("\t\t\t                     __####__\n");
      printf("\t\t\t                       _##_\n");
      printf("\t\t\t___Code by Anuwat.______#________\n");
      printf("\t\t\t___For Ehm.______________\n");
      
      getch();
      
      
      
      }
