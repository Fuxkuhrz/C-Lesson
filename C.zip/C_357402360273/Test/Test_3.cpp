#include <stdio.h>
#include <conio.h>

main()
{
      printf("Calculator \n\n");
      printf("A = %d\n", 5);
      printf("B = %d\n", 10);
      printf("A + B = %d\n\n", 5+10);
      
      int x = 10, y = 20, z;
      z = x + y;
      printf("%d + %d = %d", x, y, z);  
      
      
      getch();
      
      
      
      
      
      }

