#include <stdio.h>
#include <conio.h>

#define PI 3.14159

main()
{     //5.4
      float radius = 7.5, area;
      area = PI * radius * radius;
      
      printf("Radiuse of circle is %.2f\n", radius);
      printf("Area of circle is %.2f\n\n", area);
      
      //5.5
      char name[20] = "Sunee";
      char grade = 'A';
      float avg = 4.00;
      
      printf("My name is %s\n", name);
      printf("Grade is %c\n", grade);
      printf("Average is %.2f\n", avg);
      
      
      
      
      getch();
      
      
      
      
      
      
      
      
      
      
      
      }
