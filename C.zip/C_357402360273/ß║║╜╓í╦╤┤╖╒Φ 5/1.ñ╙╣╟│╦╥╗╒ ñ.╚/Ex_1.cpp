//code by Anuwat Khongchuai ^_^ 
// AKA >> Elaeis guineensis Jacq. (Palm)
// Convert BE to CE with C Programming
#include <stdio.h>
#include <conio.h>
main(){
       
       char name[15];
       int be, ce;
       //
       
       printf("Please input your name : >> ");
       scanf("%s", name);
       //
       printf("Please input your BE : >> ");
       scanf("%d", &be);
       //
       ce = be - 543;
       //
       printf("Your CE is : >> %d\n\n", ce);
       //
       
       printf("Press any key to exit.");
       getch();
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       }
