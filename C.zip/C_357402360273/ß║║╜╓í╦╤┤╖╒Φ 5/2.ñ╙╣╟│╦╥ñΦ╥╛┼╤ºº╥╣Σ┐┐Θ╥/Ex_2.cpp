//code by Anuwat Khongchuai ^_^ 
// AKA >> Elaeis guineensis Jacq. (Palm)
// find energy value with C Programming. 
#include <stdio.h>
#include <conio.h>
main(){
       
     char name[20];
     float Q, V, W;
     //
     printf("Please input your name : >> ");
     scanf("%s", name);
     //
     printf("Please input your Q value : >> ");
     scanf("%f", &Q);
     //
     printf("Please input your V value : >> ");
     scanf("%f", &V);
     
     W = Q * V;
     
     printf("Value of Q x V = %.2f\n\n", W);
     //
     printf("Press any key to exit.");
     getch();
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       }
