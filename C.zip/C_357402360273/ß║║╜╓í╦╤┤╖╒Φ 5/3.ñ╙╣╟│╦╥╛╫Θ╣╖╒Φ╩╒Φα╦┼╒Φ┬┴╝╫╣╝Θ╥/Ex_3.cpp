//code by Anuwat Khongchuai ^_^ 
// AKA >> Elaeis guineensis Jacq. (Palm)
// find rectangle  area with C Programming. 
#include <stdio.h>
#include <conio.h>
main(){
       
     float w, l, area;
     //
     printf("Please input your width : >> ");
     scanf("%f", &w);
     //
     printf("Please input your length : >> ");
     scanf("%f", &l);
     //
     area = w * l;
     printf("Area is : %.2f\n\n", area);
     //
     printf("Press any key to exit");
     getch();
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       }
